#ifdef _WIN32
#define GLUT_DISABLE_ATEXIT_HACK
#endif

#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>
#include <math.h>

// Global variables for rotation and robot movement
static GLfloat theta[] = {0.0, 0.0, 0.0};
static GLint axis = 2;
static GLdouble viewer[] = {0.0, 0.0, 5.0};
GLfloat robotPosition[] = {0.0, 0.0, 0.0};
GLfloat robotRotation = 0.0;
GLboolean isWaving = GL_FALSE;
GLfloat armAngle = 0.0;
GLfloat waveSpeed = 2.0;

// Materials and lighting
void setMaterial(GLfloat amb[], GLfloat diff[], GLfloat spec[], GLfloat shin) {
    glMaterialfv(GL_FRONT, GL_AMBIENT, amb);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR, spec);
    glMaterialf(GL_FRONT, GL_SHININESS, shin);
}

// Draw robot parts
void drawHead() {
    GLfloat ambient[] = {0.0, 0.5, 0.8, 1.0}; // Blue color
    GLfloat diffuse[] = {0.0, 0.5, 0.8, 1.0};
    GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
    setMaterial(ambient, diffuse, specular, 50.0);

    glPushMatrix();
    glutSolidSphere(0.25, 20, 20);

    // Eyes
    glPushMatrix();
    GLfloat eyeAmbient[] = {1.0, 1.0, 1.0, 1.0};
    setMaterial(eyeAmbient, eyeAmbient, specular, 50.0);
    glTranslatef(0.1, 0.1, 0.2);
    glutSolidSphere(0.05, 10, 10);
    glTranslatef(-0.2, 0.0, 0.0);
    glutSolidSphere(0.05, 10, 10);
    glPopMatrix();

    glPopMatrix();
}

void drawBody() {
    GLfloat ambient[] = {0.7, 0.0, 0.7, 1.0}; // Purple color
    GLfloat diffuse[] = {0.7, 0.0, 0.7, 1.0};
    GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
    setMaterial(ambient, diffuse, specular, 50.0);

    glPushMatrix();
    glScalef(0.5, 0.7, 0.3);
    glutSolidCube(1.0);
    glPopMatrix();
}

void drawArm(GLboolean isLeft) {
    GLfloat ambient[] = {0.0, 0.8, 0.5, 1.0}; // Turquoise color
    GLfloat diffuse[] = {0.0, 0.8, 0.5, 1.0};
    GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
    setMaterial(ambient, diffuse, specular, 50.0);

    glPushMatrix();
    if (isLeft) {
        glTranslatef(0.3, 0.0, 0.0);
        if (isWaving) {
            glRotatef(armAngle, 0.0, 0.0, 1.0);
        }
    } else {
        glTranslatef(-0.3, 0.0, 0.0);
    }
    glScalef(0.1, 0.4, 0.1);
    glutSolidCube(1.0);
    glPopMatrix();
}

void drawLegs() {
    GLfloat ambient[] = {0.0, 0.8, 0.5, 1.0}; // Turquoise color
    GLfloat diffuse[] = {0.0, 0.8, 0.5, 1.0};
    GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
    setMaterial(ambient, diffuse, specular, 50.0);

    glPushMatrix();
    glTranslatef(0.15, -0.5, 0.0);
    glScalef(0.1, 0.4, 0.1);
    glutSolidCube(1.0);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.15, -0.5, 0.0);
    glScalef(0.1, 0.4, 0.1);
    glutSolidCube(1.0);
    glPopMatrix();
}

void drawZehraRobot() {
    glPushMatrix();
    glTranslatef(robotPosition[0], robotPosition[1], robotPosition[2]);
    glRotatef(robotRotation, 0.0, 1.0, 0.0);

    // Draw robot parts
    glPushMatrix();
    glTranslatef(0.0, 0.5, 0.0);
    drawHead();
    glPopMatrix();

    drawBody();
    drawArm(GL_TRUE);  // Left arm
    drawArm(GL_FALSE); // Right arm
    drawLegs();

    glPopMatrix();
}

void update(int value) {
    if (isWaving) {
        armAngle += waveSpeed;
        if (armAngle > 45.0) waveSpeed = -2.0;
        if (armAngle < -45.0) waveSpeed = 2.0;
    }
    glutPostRedisplay();
    glutTimerFunc(16, update, 0);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(viewer[0], viewer[1], viewer[2], 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    // Set up lighting
    GLfloat lightPosition[] = {5.0, 5.0, 5.0, 1.0};
    GLfloat lightIntensity[] = {0.7, 0.7, 0.7, 1.0};
    glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightIntensity);

    // Draw the scene
    drawZehraRobot();

    glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'w': robotPosition[2] -= 0.1; break;
        case 's': robotPosition[2] += 0.1; break;
        case 'a': robotPosition[0] -= 0.1; break;
        case 'd': robotPosition[0] += 0.1; break;
        case 'q': robotRotation += 5.0; break;
        case 'e': robotRotation -= 5.0; break;
        case ' ': isWaving = !isWaving; break;
        case 27:  exit(0); break; // ESC key
    }
    glutPostRedisplay();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (GLfloat)w/(GLfloat)h, 1.0, 20.0);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Zehra Robot");

    // Initialize OpenGL settings
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);
    glClearColor(0.1, 0.1, 0.1, 1.0);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(0, update, 0);

    glutMainLoop();
    return 0;
}
